//#-code-completion(identifier, hide, setupLiveView())
//#-hidden-code
import Foundation
//#-end-hidden-code
//#-editable-code Tap to enter code
show("What is your name?")

let name = ask("Name")

show("Hi " + name)

//#-end-editable-code
